from sqlalchemy.orm import Session

from . import models, schemas


def create_reading(db: Session, reading: schemas.SensorReadingIn) -> models.SensorReading:
    db_reading = models.SensorReading(
        station_id=reading.station_id,
        timestamp=reading.timestamp,
        pm25=reading.pm25,
        pm10=reading.pm10,
        no2=reading.no2,
        so2=reading.so2,
        co=reading.co,
        o3=reading.o3,
        temp_c=reading.temp_c,
        humidity_pct=reading.humidity_pct,
        wind_speed_mps=reading.wind_speed_mps,
        wind_direction_deg=reading.wind_direction_deg,
        pressure_hpa=reading.pressure_hpa,
        rain_mm=reading.rain_mm,
    )
    db.add(db_reading)
    db.commit()
    db.refresh(db_reading)
    return db_reading


def get_history(db: Session, station_id: int, hours: int) -> list[models.SensorReading]:
    """Most recent `hours` readings for a station, returned ascending by time."""
    rows = (
        db.query(models.SensorReading)
        .filter(models.SensorReading.station_id == station_id)
        .order_by(models.SensorReading.timestamp.desc())
        .limit(hours)
        .all()
    )
    rows.reverse()
    return rows


def save_prediction(db: Session, station_id: int, based_on_timestamp, predictions: dict) -> models.Prediction:
    pred = models.Prediction(
        station_id=station_id,
        based_on_timestamp=based_on_timestamp,
        predictions=predictions,
    )
    db.add(pred)
    db.commit()
    db.refresh(pred)
    return pred


def get_predictions(db: Session, station_id: int, limit: int = 20) -> list[models.Prediction]:
    return (
        db.query(models.Prediction)
        .filter(models.Prediction.station_id == station_id)
        .order_by(models.Prediction.based_on_timestamp.desc())
        .limit(limit)
        .all()
    )
