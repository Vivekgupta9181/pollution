from sqlalchemy import Column, Integer, Float, DateTime, JSON, Index
from sqlalchemy.sql import func

from .database import Base


class SensorReading(Base):
    """
    One raw hourly reading from a station. Names use plain ASCII so the
    ORM/DB stay simple — the subscript column names (NO₂, SO₂, O₃) from the
    training CSV only get reconstructed inside feature_engineering.py.
    """

    __tablename__ = "sensor_readings"

    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(Integer, nullable=False, index=True)
    timestamp = Column(DateTime(timezone=True), nullable=False, index=True)

    pm25 = Column(Float, nullable=False)
    pm10 = Column(Float, nullable=False)
    no2 = Column(Float, nullable=False)
    so2 = Column(Float, nullable=False)
    co = Column(Float, nullable=False)
    o3 = Column(Float, nullable=False)
    temp_c = Column(Float, nullable=False)
    humidity_pct = Column(Float, nullable=False)
    wind_speed_mps = Column(Float, nullable=False)
    wind_direction_deg = Column(Float, nullable=False)
    pressure_hpa = Column(Float, nullable=False)
    rain_mm = Column(Float, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index("ix_station_timestamp", "station_id", "timestamp"),
    )


class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(Integer, nullable=False, index=True)
    based_on_timestamp = Column(DateTime(timezone=True), nullable=False)
    predictions = Column(JSON, nullable=False)  # {"PM2.5_target_1h": 34.2, ...}

    created_at = Column(DateTime(timezone=True), server_default=func.now())
