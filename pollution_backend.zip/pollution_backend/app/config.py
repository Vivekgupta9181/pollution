from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    All config is pulled from environment variables / a .env file.
    DATABASE_URL should be your Neon connection string, e.g.:
    postgresql://user:password@ep-xxxx.neon.tech/dbname?sslmode=require
    """

    database_url: str
    model_dir: str = "models"
    history_window_hours: int = 48   # how many past rows we pull to build features
    min_history_rows: int = 25       # need >24h of prior rows for the 24h rolling mean

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
