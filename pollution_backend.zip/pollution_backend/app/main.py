from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from . import crud, schemas
from .config import settings
from .database import Base, engine, get_db
from .feature_engineering import build_feature_row, readings_to_training_frame

# NOTE: for a hackathon this is fine. For anything longer-lived, swap to
# Alembic migrations instead of create_all.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Urban Air Pollution Prediction API",
    description="Ingests hourly station readings, engineers the same "
    "features used at training time, and serves PM2.5 / PM10 forecasts "
    "(1h-5h ahead) from the trained RandomForestRegressor.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _get_ml_service():
    # imported lazily so the app can still start (and fail loudly with a
    # clear message) if the .pkl files aren't in place yet
    from .ml_service import ml_service
    return ml_service


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/readings", response_model=schemas.SensorReadingOut, status_code=201)
def ingest_reading(reading: schemas.SensorReadingIn, db: Session = Depends(get_db)):
    """Store one raw hourly reading for a station."""
    return crud.create_reading(db, reading)


@app.get("/readings/{station_id}", response_model=list[schemas.SensorReadingOut])
def list_readings(station_id: int, hours: int = 48, db: Session = Depends(get_db)):
    """Most recent readings for a station, oldest first."""
    return crud.get_history(db, station_id, hours)


@app.post("/predict/{station_id}", response_model=schemas.PredictionOut)
def predict(station_id: int, db: Session = Depends(get_db)):
    """
    Predict PM2.5 / PM10 1h-5h ahead for a station, using the most recent
    readings already stored in the DB (no body needed).
    """
    ml_service = _get_ml_service()

    rows = crud.get_history(db, station_id, hours=settings.history_window_hours)
    if len(rows) < settings.min_history_rows:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Need at least {settings.min_history_rows} hourly readings for "
                f"station {station_id} to build lag/rolling features; have {len(rows)}. "
                "POST more readings to /readings first."
            ),
        )

    df = readings_to_training_frame(rows)
    try:
        feature_row = build_feature_row(df, ml_service.feature_columns)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    predictions = ml_service.predict(feature_row)
    latest_ts = rows[-1].timestamp
    crud.save_prediction(db, station_id, latest_ts, predictions)

    return schemas.PredictionOut(
        station_id=station_id,
        based_on_timestamp=latest_ts,
        predictions=predictions,
    )


@app.post("/ingest-and-predict/{station_id}", response_model=schemas.PredictionOut)
def ingest_and_predict(station_id: int, reading: schemas.SensorReadingIn, db: Session = Depends(get_db)):
    """Convenience endpoint: store a new reading, then immediately predict off it."""
    if reading.station_id != station_id:
        raise HTTPException(status_code=400, detail="station_id in path and body must match")
    crud.create_reading(db, reading)
    return predict(station_id, db)


@app.get("/predictions/{station_id}", response_model=list[schemas.PredictionOut])
def list_predictions(station_id: int, limit: int = 20, db: Session = Depends(get_db)):
    """Prediction history for a station, most recent first."""
    preds = crud.get_predictions(db, station_id, limit)
    return [
        schemas.PredictionOut(
            station_id=p.station_id,
            based_on_timestamp=p.based_on_timestamp,
            predictions=p.predictions,
        )
        for p in preds
    ]
