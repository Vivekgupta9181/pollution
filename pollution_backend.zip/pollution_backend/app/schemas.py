from datetime import datetime
from typing import Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class SensorReadingIn(BaseModel):
    """
    Payload for one raw hourly reading. Field names are plain ASCII on
    purpose (no unicode subscripts) so this is easy to send from any
    client / ESP32 / Postman without encoding headaches.
    """

    station_id: int = Field(..., ge=1, le=5, description="1-5, matches training data stations")
    timestamp: datetime

    pm25: float = Field(..., description="PM2.5 (µg/m³)")
    pm10: float = Field(..., description="PM10 (µg/m³)")
    no2: float = Field(..., description="NO2")
    so2: float = Field(..., description="SO2")
    co: float
    o3: float = Field(..., description="O3")
    temp_c: float
    humidity_pct: float
    wind_speed_mps: float
    wind_direction_deg: float = Field(..., ge=0, le=360)
    pressure_hpa: float
    rain_mm: float

    model_config = ConfigDict(json_schema_extra={
        "example": {
            "station_id": 1,
            "timestamp": "2026-09-06T10:00:00Z",
            "pm25": 55.2,
            "pm10": 88.4,
            "no2": 21.3,
            "so2": 8.7,
            "co": 0.9,
            "o3": 34.1,
            "temp_c": 29.5,
            "humidity_pct": 68.0,
            "wind_speed_mps": 3.2,
            "wind_direction_deg": 210.0,
            "pressure_hpa": 1008.5,
            "rain_mm": 0.0,
        }
    })


class SensorReadingOut(SensorReadingIn):
    id: int

    model_config = ConfigDict(from_attributes=True)


class PredictionOut(BaseModel):
    station_id: int
    based_on_timestamp: datetime
    predictions: Dict[str, float]

    model_config = ConfigDict(from_attributes=True)
