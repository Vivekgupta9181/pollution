"""
Re-implements, row-for-row, the feature engineering from the training
script (UrbanAirPollutionDataset -> RandomForestRegressor) so that
features built at inference time are computed exactly the same way as
during training. If you change the training script, mirror the change
here too, or predictions will silently drift from what the model learned.
"""

import numpy as np
import pandas as pd

# Columns that get rate-of-change features (1h..5h)
ROC_COLUMNS = ["NO₂", "SO₂", "CO", "O₃", "Temp_C", "Humidity_%"]

# Columns that get lag + rolling-mean features
LAG_COLUMNS = ["PM2.5", "PM10"]
ROLLING_WINDOWS = [3, 6, 12, 24]

SEASONS = ["monsoon", "post_monsoon", "summer", "winter"]

# Minimum trailing rows needed to fill every engineered feature for the
# newest row (24h rolling mean is the deepest lookback we need).
MIN_HISTORY_ROWS = 25


def season_from_month(month: int) -> str:
    if month in (12, 1, 2):
        return "winter"
    if month in (3, 4, 5):
        return "summer"
    if month in (6, 7, 8, 9):
        return "monsoon"
    return "post_monsoon"


def build_feature_row(history_df: pd.DataFrame, feature_columns: list[str]) -> pd.DataFrame:
    """
    Parameters
    ----------
    history_df : raw readings for ONE station, ascending by DateTime, with
        the newest (to-be-predicted) reading as the LAST row. Must contain
        the training column names: DateTime, Station_ID, PM2.5, PM10,
        NO₂, SO₂, CO, O₃, Temp_C, Humidity_%, Wind_Speed_mps,
        Wind_Direction_deg, Pressure_hPa, Rain_mm.
    feature_columns : the exact ordered list of columns the trained model
        expects (load this from model_features.pkl — never hardcode it,
        so a retrained model with different features still works).

    Returns
    -------
    A single-row DataFrame, column order matching feature_columns, ready
    to pass straight into model.predict().
    """
    df = history_df.sort_values("DateTime").reset_index(drop=True).copy()

    # --- time features ---
    df["hour"] = df["DateTime"].dt.hour
    df["day_of_week"] = df["DateTime"].dt.dayofweek
    df["month"] = df["DateTime"].dt.month
    df["season"] = df["month"].apply(season_from_month)

    df["hour_sin"] = np.sin(2 * np.pi * df["hour"] / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["hour"] / 24)
    df["dow_sin"] = np.sin(2 * np.pi * df["day_of_week"] / 7)
    df["dow_cos"] = np.cos(2 * np.pi * df["day_of_week"] / 7)

    # --- wind direction ---
    df["wind_dir_sin"] = np.sin(np.deg2rad(df["Wind_Direction_deg"]))
    df["wind_dir_cos"] = np.cos(np.deg2rad(df["Wind_Direction_deg"]))

    # --- rate of change (1h..5h) ---
    for col in ROC_COLUMNS:
        for h in range(1, 6):
            df[f"{col}_ROC_{h}h"] = (df[col] - df[col].shift(h)) / h

    # --- lag features (1h..5h) ---
    for col in LAG_COLUMNS:
        for h in range(1, 6):
            df[f"{col}_lag_{h}h"] = df[col].shift(h)

    # --- rolling means (shifted 1 first, same as training) ---
    for col in LAG_COLUMNS:
        for w in ROLLING_WINDOWS:
            df[f"{col}_rolling_mean_{w}h"] = df[col].shift(1).rolling(window=w).mean()

    latest = df.iloc[[-1]].copy()

    # --- season one-hot (all 4 dummies, matching pd.get_dummies at train time) ---
    for s in SEASONS:
        latest[f"season_{s}"] = int(latest["season"].iloc[0] == s)

    # --- station one-hot ---
    station_id = latest["Station_ID"].iloc[0]
    for col in feature_columns:
        if col.startswith("station_"):
            latest[col] = int(str(station_id) == col.split("_", 1)[1])

    latest = latest.reindex(columns=feature_columns)

    missing_mask = latest.isna().iloc[0]
    if missing_mask.any():
        missing = latest.columns[missing_mask].tolist()
        raise ValueError(
            "Not enough history to compute all features. Missing: "
            f"{missing}. This station needs at least {MIN_HISTORY_ROWS} "
            "prior hourly readings before a prediction can be made."
        )

    return latest


def readings_to_training_frame(rows) -> pd.DataFrame:
    """
    Convert a list of SensorReading ORM rows (ascending by timestamp) into
    a DataFrame using the original training column names.
    """
    data = [
        {
            "DateTime": r.timestamp,
            "Station_ID": r.station_id,
            "PM2.5": r.pm25,
            "PM10": r.pm10,
            "NO₂": r.no2,
            "SO₂": r.so2,
            "CO": r.co,
            "O₃": r.o3,
            "Temp_C": r.temp_c,
            "Humidity_%": r.humidity_pct,
            "Wind_Speed_mps": r.wind_speed_mps,
            "Wind_Direction_deg": r.wind_direction_deg,
            "Pressure_hPa": r.pressure_hpa,
            "Rain_mm": r.rain_mm,
        }
        for r in rows
    ]
    return pd.DataFrame(data)
