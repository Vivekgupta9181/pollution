from pathlib import Path

import joblib
import pandas as pd

from .config import settings


class MLService:
    """
    Loads the artifacts produced by the training script:
      - pollution_model.pkl    (trained RandomForestRegressor)
      - model_features.pkl     (ordered list of X_train column names)
      - target_columns.pkl     (ordered list of target column names)
    and wraps them behind a single .predict() call.
    """

    def __init__(self, model_dir: str):
        model_path = Path(model_dir)

        required = ["pollution_model.pkl", "model_features.pkl", "target_columns.pkl"]
        missing = [f for f in required if not (model_path / f).exists()]
        if missing:
            raise FileNotFoundError(
                f"Missing model artifact(s) in '{model_path}': {missing}. "
                "Copy the .pkl files produced by the training script into this folder."
            )

        self.model = joblib.load(model_path / "pollution_model.pkl")
        self.feature_columns: list[str] = joblib.load(model_path / "model_features.pkl")
        self.target_columns: list[str] = joblib.load(model_path / "target_columns.pkl")

    def predict(self, feature_row: pd.DataFrame) -> dict[str, float]:
        X = feature_row[self.feature_columns]
        preds = self.model.predict(X)[0]
        return {target: float(value) for target, value in zip(self.target_columns, preds)}


# Loaded once at import time (i.e. once per process) — cheap because
# joblib.load only happens on startup, not per-request.
ml_service = MLService(settings.model_dir)
