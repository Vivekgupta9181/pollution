"""
Optional helper for demos: loads the same UrbanAirPollutionDataset.csv
used for training and inserts the most recent N hours per station into
Neon, so /predict has enough history to work immediately without you
manually POSTing 25+ readings by hand.

Usage:
    python seed_from_csv.py path/to/UrbanAirPollutionDataset.csv --hours-per-station 72
"""

import argparse

import pandas as pd
from sqlalchemy.orm import Session

from app.database import Base, SessionLocal, engine
from app import models


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_path")
    parser.add_argument("--hours-per-station", type=int, default=72)
    args = parser.parse_args()

    Base.metadata.create_all(bind=engine)

    df = pd.read_csv(args.csv_path)
    df["DateTime"] = pd.to_datetime(df["DateTime"], errors="coerce")
    df = df.dropna(subset=["DateTime"]).sort_values(["Station_ID", "DateTime"])

    db: Session = SessionLocal()
    inserted = 0
    try:
        for station_id, group in df.groupby("Station_ID"):
            tail = group.tail(args.hours_per_station)
            for _, row in tail.iterrows():
                db.add(models.SensorReading(
                    station_id=int(station_id),
                    timestamp=row["DateTime"],
                    pm25=row["PM2.5"],
                    pm10=row["PM10"],
                    no2=row["NO₂"],
                    so2=row["SO₂"],
                    co=row["CO"],
                    o3=row["O₃"],
                    temp_c=row["Temp_C"],
                    humidity_pct=row["Humidity_%"],
                    wind_speed_mps=row["Wind_Speed_mps"],
                    wind_direction_deg=row["Wind_Direction_deg"],
                    pressure_hpa=row["Pressure_hPa"],
                    rain_mm=row["Rain_mm"],
                ))
                inserted += 1
        db.commit()
    finally:
        db.close()

    print(f"Inserted {inserted} rows across {df['Station_ID'].nunique()} stations.")


if __name__ == "__main__":
    main()
